# Simple Minesweeper by nevikw39
![Imgur](https://imgur.com/DFJmoxS.png)
> A simple minesweeper game using *PyGame*.

## Usage
```bash
pip3 install -r requirements.txt
python3 main.py
```

## Logs
+ 0102
  - 基底完成
+ 0103
  - 色彩調整
  - 加入遊戲結束提示
+ 0104
  - 加入記時及顯示剩餘地雷功能
+ 0105
  - 色彩最佳化
+ 0110
  - 修正勝場判定
  - 加入自動展開功能
  - 加入矛盾提示功能
+ 0116
  - 加入聲音加入聲音