# Pygame 2048 
有動畫ㄉ喔😀

要記得先安裝Pygameㄛ🧡

```
pip install pygame
```

![](https://i.imgur.com/9GtElIm.png)

![](https://i.imgur.com/Tfenb0L.png)

## [影片❤](https://youtu.be/4oGY6HaXgAE)
